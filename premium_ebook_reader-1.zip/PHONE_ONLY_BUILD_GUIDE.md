# Sirf Phone Se APK Kaise Banayein (No Computer Needed)

Aapka code cloud pe build hoga (GitHub Actions) — free hai, aur poora process phone ke
browser se ho sakta hai.

## Step 1 — GitHub account banayein
1. Phone browser mein jayein: https://github.com/signup
2. Free account bana lein

## Step 2 — Naya repository banayein
1. GitHub pe sign in karke, top-right "+" icon → **New repository**
2. Naam dein: `premium-ebook-reader`
3. **Public** select karein (private bhi chalega, free hai)
4. **Create repository** dabayein

## Step 3 — Files upload karein
1. Repository page pe **"uploading an existing file"** link pe tap karein
   (agar ye link na dikhe, to "Add file" → "Upload files")
2. Zip file jo maine di hai usse **pehle apne phone mein unzip** karein
   (koi bhi File Manager app se — jaise "Files by Google" mein unzip option hota hai)
3. Unzip ke baad andar ki **saari files aur folders select karke** GitHub upload screen
   pe drag/select karein — poori folder structure (pubspec.yaml, lib/, .github/) waise hi rakhein
4. Neeche **"Commit changes"** button dabayein

   ⚠️ Important: `.github` folder hidden ho sakta hai kuch file managers mein — agar wo
   upload na ho, to niche diya hua `build.yml` content copy karke GitHub website pe hi
   naya file bana lein: repo mein "Add file" → "Create new file" → naam type karein
   `.github/workflows/build.yml` (GitHub khud folder bana dega) → content paste karein → commit.

## Step 4 — Build automatically start ho jayega
1. Repository ke top pe **"Actions"** tab pe tap karein
2. Aapko "Build Android APK" workflow chalte hue dikhega (2-6 minute lagte hain)
3. Green tick ✅ aane ka wait karein

## Step 5 — APK download karein
1. Us completed workflow run pe tap karein
2. Neeche scroll karein **"Artifacts"** section tak
3. **"app-release-apk"** pe tap karke download karein — ye ek `.zip` hoga
4. Us zip ko unzip karein → andar `app-release.apk` milega
5. Us APK pe tap karke install karein (pehli baar "Install unknown apps" allow karna padega)

---

## Agar Actions tab pe workflow na chale
- Repo ke **Settings → Actions → General** mein jayein
- "Workflow permissions" ko **Read and write** kar dein, aur "Allow all actions" enabled
  hona chahiye — phir "Actions" tab pe wapas jaake **"Run workflow"** button se manually
  trigger kar sakte hain.

## Notes
- Ye pura process **free** hai — GitHub Actions free tier public repos ke liye kaafi generous hai.
- Har baar jab aap code mein change karke commit karenge, naya APK apne aap ban jayega —
  bas Actions tab se download karna hoga.
