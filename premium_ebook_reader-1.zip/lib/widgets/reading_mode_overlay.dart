import 'package:flutter/material.dart';

enum ReadingMode { light, dark, sepia }

/// Wraps the PDF view with a color filter to simulate Dark/Sepia reading
/// modes without needing to re-render the PDF pixels themselves.
class ReadingModeOverlay extends StatelessWidget {
  final ReadingMode mode;
  final Widget child;

  const ReadingModeOverlay({
    super.key,
    required this.mode,
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    switch (mode) {
      case ReadingMode.light:
        return child;

      case ReadingMode.sepia:
        // Warm, paper-like tone
        return ColorFiltered(
          colorFilter: const ColorFilter.matrix(<double>[
            0.9, 0.1, 0.0, 0, 15,
            0.0, 0.85, 0.15, 0, 10,
            0.0, 0.1, 0.7, 0, 0,
            0, 0, 0, 1, 0,
          ]),
          child: Container(color: const Color(0xFFF4ECD8), child: child),
        );

      case ReadingMode.dark:
        // Inverts luminance for a true dark-mode PDF page (keeps images readable)
        return ColorFiltered(
          colorFilter: const ColorFilter.matrix(<double>[
            -1, 0, 0, 0, 255,
            0, -1, 0, 0, 255,
            0, 0, -1, 0, 255,
            0, 0, 0, 1, 0,
          ]),
          child: child,
        );
    }
  }
}
