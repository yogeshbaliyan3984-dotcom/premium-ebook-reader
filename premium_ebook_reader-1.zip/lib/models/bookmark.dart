import 'package:hive/hive.dart';

part 'bookmark.g.dart';

@HiveType(typeId: 1)
class Bookmark extends HiveObject {
  @HiveField(0)
  String bookId; // path or unique id of the PDF

  @HiveField(1)
  int pageNumber; // 0-indexed page

  @HiveField(2)
  String label; // e.g. "Chapter 3 - Interesting point"

  @HiveField(3)
  DateTime createdAt;

  Bookmark({
    required this.bookId,
    required this.pageNumber,
    required this.label,
    required this.createdAt,
  });
}
