# Premium eBook Reader — Setup Instructions

## 1. Prerequisites (on your computer)
- Flutter SDK installed (https://docs.flutter.dev/get-started/install)
- Android Studio (for Android build/emulator) — and Xcode if you also want an iOS build (Mac only)
- A physical Android phone with USB debugging on, OR an emulator

## 2. Create the project & drop in these files
```bash
flutter create premium_ebook_reader
cd premium_ebook_reader
```
Then replace/add the files exactly as given here (same folder paths):
- `pubspec.yaml`
- `lib/models/bookmark.dart`
- `lib/models/note.dart`
- `lib/models/reading_progress.dart`
- `lib/services/storage_service.dart`
- `lib/widgets/reading_mode_overlay.dart`
- `lib/screens/reader_screen.dart`

## 3. Install dependencies
```bash
flutter pub get
```

## 4. Generate Hive adapters (required — bookmark.g.dart, note.g.dart, reading_progress.g.dart)
```bash
dart run build_runner build --delete-conflicting-outputs
```
This auto-generates the `*.g.dart` files referenced by `part 'bookmark.g.dart';` etc.
Without this step the app will NOT compile — this step is mandatory every time you add/change
a `@HiveType` model.

## 5. Minimal main.dart to wire it together
Create/replace `lib/main.dart` with:
```dart
import 'package:flutter/material.dart';
import 'services/storage_service.dart';
import 'screens/reader_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await StorageService.init();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Premium eBook Reader',
      theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.indigo),
      darkTheme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.indigo,
        brightness: Brightness.dark,
      ),
      home: const ReaderScreen(
        bookId: 'sample_book',                 // use file path as unique id in production
        filePath: '/path/to/your/file.pdf',     // e.g. from file_picker or app documents dir
        title: 'My Book',
      ),
    );
  }
}
```

## 6. Run it
```bash
flutter run
```

## 7. Build the installable APK
```bash
flutter build apk --release
```
The installable file will be at:
`build/app/outputs/flutter-apk/app-release.apk`
→ copy this to your phone and install (enable "Install from unknown sources" if prompted).

## 8. For iOS (Mac + Xcode required)
```bash
flutter build ios --release
```
Then archive & export via Xcode (needs an Apple Developer account to install on a real device
or publish to the App Store).

---

## What's implemented so far (Step 3)
- ✅ Native page-flip / swipe (flutter_pdfview, GPU accelerated)
- ✅ Horizontal page-flip mode + vertical scroll toggle
- ✅ Light / Dark / Sepia reading modes (color-filter overlay, preserves original PDF vectors/images)
- ✅ Pinch-to-zoom (built into flutter_pdfview)
- ✅ Fullscreen toggle
- ✅ Screen-awake lock while reading (wakelock_plus)
- ✅ Persistent reading progress — auto-saves last page (debounced) via Hive
- ✅ Quick bookmarking + notes, saved locally via Hive
- ✅ Bottom page slider for quick jump

## Still to build (next steps)
- `pdf_service.dart` — TOC/outline extraction + full-text search index (using `pdfx`)
- `library_screen.dart` — home screen, PDF import via `file_picker`
- `toc_screen.dart`, `search_screen.dart`, `bookmarks_screen.dart`, `notes_screen.dart`
- Brightness slider UI (the `screen_brightness` package is already wired for restore/reset)

Let me know and I'll build these next.
